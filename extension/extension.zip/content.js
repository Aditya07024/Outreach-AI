"use strict";
(() => {
  // src/content/extractor.ts
  var EMAIL_REGEX = /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*/g;
  var FAKE_EMAIL_PATTERNS = [
    /^test@/i,
    /^example@/i,
    /^user@/i,
    /^email@/i,
    /^name@/i,
    /^your@/i,
    /^someone@/i,
    /^noreply@/i,
    /^no-reply@/i,
    /^donotreply@/i,
    /^do-not-reply@/i,
    /^mailer-daemon@/i,
    /^postmaster@/i,
    /^webmaster@/i,
    /^localhost$/i,
    /^sentry\./i,
    /^wixpress\.com$/i,
    /@example\./i,
    /@test\./i,
    /@localhost/i,
    /@sentry\./i
  ];
  var FAKE_TLDS = ["png", "jpg", "jpeg", "gif", "svg", "webp", "css", "js", "ts", "jsx", "tsx", "json", "xml", "woff", "woff2", "ttf", "eot", "map", "min"];
  var CLASSIFICATION_MAP = {
    "hr": "Recruitment",
    "career": "Recruitment",
    "careers": "Recruitment",
    "jobs": "Recruitment",
    "recruiting": "Recruitment",
    "recruitment": "Recruitment",
    "talent": "Recruitment",
    "hiring": "Recruitment",
    "support": "Support",
    "help": "Support",
    "helpdesk": "Support",
    "customerservice": "Support",
    "service": "Support",
    "sales": "Sales",
    "business": "Sales",
    "partnerships": "Sales",
    "partner": "Sales",
    "info": "General",
    "hello": "General",
    "contact": "General",
    "general": "General",
    "office": "General",
    "team": "General",
    "founder": "Founder",
    "ceo": "Founder",
    "cto": "Founder",
    "coo": "Founder",
    "cfo": "Founder",
    "admin": "Administration",
    "administrator": "Administration",
    "operations": "Administration",
    "engineering": "Engineering",
    "dev": "Engineering",
    "developer": "Engineering",
    "tech": "Engineering",
    "marketing": "Marketing",
    "press": "Marketing",
    "media": "Marketing",
    "pr": "Marketing",
    "legal": "Legal",
    "compliance": "Legal",
    "privacy": "Legal",
    "finance": "Finance",
    "billing": "Finance",
    "accounting": "Finance",
    "invoices": "Finance",
    "payments": "Finance"
  };
  function classifyEmail(email) {
    const prefix = email.split("@")[0].toLowerCase().replace(/[._-]/g, "");
    for (const [key, classification] of Object.entries(CLASSIFICATION_MAP)) {
      if (prefix === key || prefix.startsWith(key)) {
        return classification;
      }
    }
    return "Unknown";
  }
  function isValidBusinessEmail(email) {
    const parts = email.split("@");
    if (parts.length !== 2) return false;
    const [, domain] = parts;
    if (!domain || !domain.includes(".")) return false;
    const tld = domain.split(".").pop()?.toLowerCase() || "";
    if (FAKE_TLDS.includes(tld)) return false;
    for (const pattern of FAKE_EMAIL_PATTERNS) {
      if (pattern.test(email) || pattern.test(domain)) return false;
    }
    if (email.length < 5 || email.length > 254) return false;
    if (domain.length < 3) return false;
    return true;
  }
  function extractFromText(text, source) {
    const matches = text.match(EMAIL_REGEX) || [];
    return matches.map((email) => ({
      email: email.toLowerCase().trim(),
      classification: classifyEmail(email),
      source
    }));
  }
  function extractFromMailtoLinks() {
    const links = document.querySelectorAll('a[href^="mailto:"]');
    const results = [];
    links.forEach((link) => {
      const href = link.getAttribute("href") || "";
      const email = href.replace("mailto:", "").split("?")[0].trim().toLowerCase();
      if (email && email.includes("@")) {
        results.push({
          email,
          classification: classifyEmail(email),
          source: "mailto-link"
        });
      }
    });
    return results;
  }
  function extractFromVisibleText() {
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: (node2) => {
          const parent = node2.parentElement;
          if (!parent) return NodeFilter.FILTER_REJECT;
          const tag = parent.tagName.toLowerCase();
          if (["script", "style", "noscript", "template"].includes(tag)) {
            return NodeFilter.FILTER_REJECT;
          }
          const style = window.getComputedStyle(parent);
          if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );
    let allVisibleText = "";
    let node;
    while (node = walker.nextNode()) {
      allVisibleText += " " + (node.textContent || "");
    }
    return extractFromText(allVisibleText, "visible-text");
  }
  function extractFromFooter() {
    const footers = document.querySelectorAll('footer, [role="contentinfo"], .footer, #footer, .site-footer');
    const results = [];
    footers.forEach((footer) => {
      const text = footer.textContent || "";
      results.push(...extractFromText(text, "footer"));
      const links = footer.querySelectorAll('a[href^="mailto:"]');
      links.forEach((link) => {
        const href = link.getAttribute("href") || "";
        const email = href.replace("mailto:", "").split("?")[0].trim().toLowerCase();
        if (email && email.includes("@")) {
          results.push({ email, classification: classifyEmail(email), source: "footer-mailto" });
        }
      });
    });
    return results;
  }
  function extractFromHeader() {
    const headers = document.querySelectorAll('header, [role="banner"], .header, #header, .site-header, .top-bar, .topbar');
    const results = [];
    headers.forEach((header) => {
      const text = header.textContent || "";
      results.push(...extractFromText(text, "header"));
    });
    return results;
  }
  function extractFromStructuredData() {
    const results = [];
    const jsonLdScripts = document.querySelectorAll('script[type="application/ld+json"]');
    jsonLdScripts.forEach((script) => {
      try {
        const data = JSON.parse(script.textContent || "");
        extractEmailsFromObject(data, results, "json-ld");
      } catch {
      }
    });
    const itemElements = document.querySelectorAll('[itemprop="email"]');
    itemElements.forEach((el) => {
      const email = (el.getAttribute("content") || el.textContent || "").trim().toLowerCase();
      if (email && email.includes("@")) {
        results.push({ email, classification: classifyEmail(email), source: "microdata" });
      }
    });
    return results;
  }
  function extractEmailsFromObject(obj, results, source) {
    if (!obj || typeof obj !== "object") return;
    if (Array.isArray(obj)) {
      obj.forEach((item) => extractEmailsFromObject(item, results, source));
      return;
    }
    for (const [key, value] of Object.entries(obj)) {
      if (typeof value === "string" && (key.toLowerCase().includes("email") || key === "contactPoint")) {
        const matches = value.match(EMAIL_REGEX);
        if (matches) {
          matches.forEach((email) => {
            results.push({ email: email.toLowerCase(), classification: classifyEmail(email), source });
          });
        }
      } else if (typeof value === "object") {
        extractEmailsFromObject(value, results, source);
      }
    }
  }
  function detectRelatedPages() {
    const contactUrls = [];
    const aboutUrls = [];
    const careersUrls = [];
    const links = document.querySelectorAll("a[href]");
    const seen = /* @__PURE__ */ new Set();
    const baseUrl = window.location.origin;
    links.forEach((link) => {
      const href = link.getAttribute("href") || "";
      const text = (link.textContent || "").trim().toLowerCase();
      let fullUrl;
      try {
        fullUrl = new URL(href, baseUrl).href;
      } catch {
        return;
      }
      if (!fullUrl.startsWith(baseUrl)) return;
      if (seen.has(fullUrl)) return;
      seen.add(fullUrl);
      const pathLower = fullUrl.toLowerCase();
      if (/\/(contact|contact-us|contactus|get-in-touch|reach-us)/i.test(pathLower) || /contact/i.test(text)) {
        contactUrls.push(fullUrl);
      }
      if (/\/(about|about-us|aboutus|our-story|who-we-are)/i.test(pathLower) || /about/i.test(text)) {
        aboutUrls.push(fullUrl);
      }
      if (/\/(careers|jobs|join-us|join|openings|positions|hiring|work-with-us)/i.test(pathLower) || /careers|jobs|join/i.test(text)) {
        careersUrls.push(fullUrl);
      }
    });
    return {
      contactUrls: [...new Set(contactUrls)].slice(0, 3),
      aboutUrls: [...new Set(aboutUrls)].slice(0, 3),
      careersUrls: [...new Set(careersUrls)].slice(0, 3)
    };
  }
  function extractEmails() {
    const allEmails = [];
    const fullText = document.body?.innerText || "";
    allEmails.push(...extractFromText(fullText, "page-text"));
    allEmails.push(...extractFromMailtoLinks());
    allEmails.push(...extractFromVisibleText());
    allEmails.push(...extractFromFooter());
    allEmails.push(...extractFromHeader());
    allEmails.push(...extractFromStructuredData());
    const emailMap = /* @__PURE__ */ new Map();
    for (const entry of allEmails) {
      const normalized = entry.email.toLowerCase().trim();
      if (!isValidBusinessEmail(normalized)) continue;
      if (!emailMap.has(normalized)) {
        emailMap.set(normalized, { ...entry, email: normalized });
      } else {
        const existing = emailMap.get(normalized);
        if (existing.classification === "Unknown" && entry.classification !== "Unknown") {
          emailMap.set(normalized, { ...entry, email: normalized });
        }
      }
    }
    return Array.from(emailMap.values());
  }
  function extractEmailsFromHTML(html, source) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");
    const allEmails = [];
    const text = doc.body?.textContent || "";
    allEmails.push(...extractFromText(text, source));
    const links = doc.querySelectorAll('a[href^="mailto:"]');
    links.forEach((link) => {
      const href = link.getAttribute("href") || "";
      const email = href.replace("mailto:", "").split("?")[0].trim().toLowerCase();
      if (email && email.includes("@")) {
        allEmails.push({ email, classification: classifyEmail(email), source: `${source}-mailto` });
      }
    });
    const jsonLdScripts = doc.querySelectorAll('script[type="application/ld+json"]');
    jsonLdScripts.forEach((script) => {
      try {
        const data = JSON.parse(script.textContent || "");
        extractEmailsFromObject(data, allEmails, `${source}-jsonld`);
      } catch {
      }
    });
    const emailMap = /* @__PURE__ */ new Map();
    for (const entry of allEmails) {
      const normalized = entry.email.toLowerCase().trim();
      if (!isValidBusinessEmail(normalized)) continue;
      if (!emailMap.has(normalized)) {
        emailMap.set(normalized, { ...entry, email: normalized });
      }
    }
    return Array.from(emailMap.values());
  }

  // src/content/company-detector.ts
  function detectCompany() {
    const domain = window.location.hostname.replace(/^www\./, "");
    const website = window.location.origin;
    const name = detectCompanyName(domain);
    const linkedinUrl = detectLinkedInUrl();
    const pageUrls = detectPageUrls();
    const industry = detectIndustry();
    const location = detectLocation();
    return {
      name,
      domain,
      website,
      linkedinUrl,
      industry,
      location,
      ...pageUrls
    };
  }
  function detectCompanyName(domain) {
    const jsonLdName = getNameFromJsonLd();
    if (jsonLdName) return jsonLdName;
    const ogName = getMetaContent("og:site_name");
    if (ogName) return ogName;
    const appName = getMetaContent("application-name");
    if (appName) return appName;
    const copyrightName = getNameFromCopyright();
    if (copyrightName) return copyrightName;
    const titleName = getNameFromTitle();
    if (titleName) return titleName;
    return prettifyDomain(domain);
  }
  function getNameFromJsonLd() {
    const scripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (const script of scripts) {
      try {
        const data = JSON.parse(script.textContent || "");
        const obj = Array.isArray(data) ? data[0] : data;
        if (obj?.name && typeof obj.name === "string") {
          return obj.name;
        }
        if (obj?.organization?.name) {
          return obj.organization.name;
        }
        if (obj?.publisher?.name) {
          return obj.publisher.name;
        }
      } catch {
      }
    }
    return null;
  }
  function getMetaContent(name) {
    const meta = document.querySelector(`meta[property="${name}"], meta[name="${name}"]`);
    const content = meta?.getAttribute("content")?.trim();
    return content && content.length > 1 && content.length < 100 ? content : null;
  }
  function getNameFromCopyright() {
    const footers = document.querySelectorAll("footer, .footer, #footer");
    for (const footer of footers) {
      const text = footer.textContent || "";
      const match = text.match(/(?:©|copyright)\s*(?:\d{4}\s*[-–]?\s*\d{0,4}\s*)?([A-Z][A-Za-z0-9\s&.,'-]{2,40})/i);
      if (match?.[1]) {
        return match[1].replace(/\s*(all rights reserved|inc|llc|ltd|co|corp)\.?\s*$/i, "").trim();
      }
    }
    return null;
  }
  function getNameFromTitle() {
    const title = document.title || "";
    const parts = title.split(/\s*[|–—·•]\s*/);
    if (parts.length > 1) {
      const lastPart = parts[parts.length - 1].trim();
      if (lastPart.length > 1 && lastPart.length < 50) return lastPart;
    }
    if (parts[0] && parts[0].trim().length > 1 && parts[0].trim().length < 50) {
      return parts[0].trim();
    }
    return null;
  }
  function prettifyDomain(domain) {
    const parts = domain.split(".");
    const name = parts.length > 1 ? parts.slice(0, -1).join(".") : parts[0];
    return name.charAt(0).toUpperCase() + name.slice(1);
  }
  function detectLinkedInUrl() {
    const links = document.querySelectorAll('a[href*="linkedin.com"]');
    for (const link of links) {
      const href = link.getAttribute("href") || "";
      if (href.includes("linkedin.com/company/") || href.includes("linkedin.com/in/")) {
        return href;
      }
    }
    return void 0;
  }
  function detectPageUrls() {
    const baseUrl = window.location.origin;
    const result = {};
    const links = document.querySelectorAll("a[href]");
    for (const link of links) {
      const href = link.getAttribute("href") || "";
      const text = (link.textContent || "").trim().toLowerCase();
      let fullUrl;
      try {
        fullUrl = new URL(href, baseUrl).href;
      } catch {
        continue;
      }
      if (!fullUrl.startsWith(baseUrl)) continue;
      const pathLower = fullUrl.toLowerCase();
      if (!result.contactUrl && (/\/(contact|contact-us|contactus|get-in-touch)/i.test(pathLower) || text === "contact" || text === "contact us")) {
        result.contactUrl = fullUrl;
      }
      if (!result.aboutUrl && (/\/(about|about-us|aboutus|our-story|who-we-are)/i.test(pathLower) || text === "about" || text === "about us")) {
        result.aboutUrl = fullUrl;
      }
      if (!result.careersUrl && (/\/(careers|jobs|join|openings|positions|hiring)/i.test(pathLower) || text === "careers" || text === "jobs")) {
        result.careersUrl = fullUrl;
      }
    }
    return result;
  }
  function detectIndustry() {
    const keywords = getMetaContent("keywords");
    if (keywords) {
      const industryKeywords = ["technology", "software", "fintech", "healthcare", "education", "ecommerce", "saas", "ai", "machine learning", "consulting", "marketing", "design", "media", "finance", "real estate", "logistics", "travel", "food", "retail"];
      const lowerKeywords = keywords.toLowerCase();
      for (const keyword of industryKeywords) {
        if (lowerKeywords.includes(keyword)) {
          return keyword.charAt(0).toUpperCase() + keyword.slice(1);
        }
      }
    }
    return void 0;
  }
  function detectLocation() {
    const scripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (const script of scripts) {
      try {
        const data = JSON.parse(script.textContent || "");
        const obj = Array.isArray(data) ? data[0] : data;
        const address = obj?.address || obj?.location?.address;
        if (address) {
          if (typeof address === "string") return address;
          const parts = [address.addressLocality, address.addressRegion, address.addressCountry].filter(Boolean);
          if (parts.length > 0) return parts.join(", ");
        }
      } catch {
      }
    }
    const geoRegion = getMetaContent("geo.region");
    const geoPlacename = getMetaContent("geo.placename");
    if (geoPlacename) return geoPlacename + (geoRegion ? `, ${geoRegion}` : "");
    return void 0;
  }

  // src/content/AutoScrollController.ts
  var AutoScrollController = class {
    state = "idle";
    processedPostIds = /* @__PURE__ */ new Set();
    noNewContentCount = 0;
    totalPostsProcessed = 0;
    startTime = 0;
    activeObserver = null;
    activeTimeout = null;
    activePolling = null;
    resumeResolver = null;
    options;
    constructor(options) {
      this.options = {
        maxPosts: options?.maxPosts ?? Infinity,
        maxRuntimeMs: options?.maxRuntimeMs ?? Infinity,
        maxConsecutiveNoNewContent: options?.maxConsecutiveNoNewContent ?? 5,
        scrollWaitTimeoutMs: options?.scrollWaitTimeoutMs ?? 3500,
        scrapeVisiblePostsFn: options?.scrapeVisiblePostsFn ?? (async () => {
          if (typeof scrapeVisiblePosts === "function") {
            await scrapeVisiblePosts();
          } else if (typeof window.scrapeVisiblePosts === "function") {
            await window.scrapeVisiblePosts();
          } else {
            console.warn("[AutoScroll] scrapeVisiblePosts function not found in scope.");
          }
        })
      };
    }
    /**
     * Start auto-scrolling execution loop.
     */
    async startAutoScroll(overrideOptions) {
      if (this.state === "running") {
        console.log("[AutoScroll] Already running");
        return;
      }
      if (this.state === "paused") {
        this.resumeAutoScroll();
        return;
      }
      if (overrideOptions) {
        this.options = {
          ...this.options,
          ...overrideOptions
        };
      }
      this.state = "running";
      this.noNewContentCount = 0;
      this.totalPostsProcessed = 0;
      this.startTime = Date.now();
      this.processedPostIds.clear();
      console.log("[AutoScroll] Started");
      try {
        await this.runLoop();
      } catch (error) {
        console.error("[AutoScroll] Error during execution loop:", error);
      } finally {
        const currentState = this.state;
        if (currentState !== "stopped" && currentState !== "idle") {
          this.stopAutoScroll();
        }
      }
    }
    /**
     * Pause auto-scrolling execution loop.
     */
    pauseAutoScroll() {
      if (this.state === "running") {
        this.state = "paused";
        console.log("[AutoScroll] Paused");
      }
    }
    /**
     * Resume auto-scrolling execution loop.
     */
    resumeAutoScroll() {
      if (this.state === "paused") {
        this.state = "running";
        console.log("[AutoScroll] Resumed");
        if (this.resumeResolver) {
          const resolve = this.resumeResolver;
          this.resumeResolver = null;
          resolve();
        }
      }
    }
    /**
     * Stop auto-scrolling execution loop and clean up resources.
     */
    stopAutoScroll() {
      if (this.state === "stopped" || this.state === "idle") {
        return;
      }
      this.state = "stopped";
      if (this.resumeResolver) {
        const resolve = this.resumeResolver;
        this.resumeResolver = null;
        resolve();
      }
      this.cleanup();
      console.log("[AutoScroll] Finished");
    }
    /**
     * Check if auto-scrolling is currently running or active.
     */
    isRunning() {
      return this.state === "running" || this.state === "paused";
    }
    /**
     * Core async loop. (Does NOT use setInterval)
     */
    async runLoop() {
      while (this.state === "running" || this.state === "paused") {
        if (this.state === "paused") {
          await this.waitForResume();
          if (this.state !== "running") break;
        }
        if (this.isMaxRuntimeReached()) {
          console.log("[AutoScroll] Maximum runtime reached");
          break;
        }
        await this.processVisiblePosts();
        if (this.state !== "running") break;
        if (this.isMaxPostsReached()) {
          console.log("[AutoScroll] Maximum posts limit reached");
          break;
        }
        console.log("[AutoScroll] Scrolling...");
        await this.scrollOneStep();
        if (this.state !== "running") break;
        console.log("[AutoScroll] Waiting for new posts...");
        const newPostsFound = await this.waitForNewPosts();
        if (this.state !== "running") break;
        if (!newPostsFound) {
          this.noNewContentCount++;
          console.log(`[AutoScroll] No new content (${this.noNewContentCount}/${this.options.maxConsecutiveNoNewContent})`);
          if (this.noNewContentCount >= this.options.maxConsecutiveNoNewContent) {
            break;
          }
        } else {
          this.noNewContentCount = 0;
        }
      }
    }
    /**
     * Wait until resumeAutoScroll() or stopAutoScroll() is invoked.
     */
    waitForResume() {
      return new Promise((resolve) => {
        this.resumeResolver = resolve;
      });
    }
    /**
     * Process currently visible posts and avoid duplicate work.
     */
    async processVisiblePosts() {
      const postElements = this.getLinkedInPostElements();
      let newlyDiscoveredCount = 0;
      for (const postEl of postElements) {
        const postId = this.getPostId(postEl);
        if (!this.processedPostIds.has(postId)) {
          this.processedPostIds.add(postId);
          newlyDiscoveredCount++;
          this.totalPostsProcessed++;
        }
      }
      await this.options.scrapeVisiblePostsFn();
      if (this.processedPostIds.size > 1e4) {
        const idsArray = Array.from(this.processedPostIds);
        this.processedPostIds = new Set(idsArray.slice(5e3));
      }
    }
    /**
     * Find visible LinkedIn post containers in the DOM.
     */
    getLinkedInPostElements() {
      const selectors = [
        ".feed-shared-update-v2",
        'div[data-urn*="activity"]',
        "div[data-activity-id]",
        ".occluded-update",
        "div.relative[data-id]",
        "article"
      ];
      const elements = document.querySelectorAll(selectors.join(", "));
      return Array.from(elements).filter((el) => {
        const rect = el.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0;
      });
    }
    /**
     * Extract or generate a unique identifier for a post element.
     */
    getPostId(element) {
      const urn = element.getAttribute("data-urn") || element.getAttribute("data-id") || element.id;
      if (urn) return urn;
      const activityId = element.getAttribute("data-activity-id");
      if (activityId) return activityId;
      const innerUrn = element.querySelector("[data-urn]")?.getAttribute("data-urn");
      if (innerUrn) return innerUrn;
      const innerActivity = element.querySelector("[data-activity-id]")?.getAttribute("data-activity-id");
      if (innerActivity) return innerActivity;
      const textSnippet = (element.textContent || "").trim().slice(0, 100).replace(/\s+/g, "_");
      if (textSnippet.length > 0) {
        return `post_text_${textSnippet}`;
      }
      return `post_elem_${Math.random().toString(36).substring(2, 9)}`;
    }
    /**
     * Determine the active scroll container or fallback to window.
     */
    getScrollContainer() {
      const candidates = [
        document.querySelector(".scaffold-finite-scroll"),
        document.querySelector(".scaffold-layout__main"),
        document.querySelector("main"),
        document.scrollingElement,
        document.documentElement,
        document.body
      ];
      for (const container of candidates) {
        if (container && container.scrollHeight > container.clientHeight && container.clientHeight > 0) {
          return container;
        }
      }
      return window;
    }
    /**
     * Get current scroll Y position from container or window.
     */
    getCurrentScrollY() {
      const container = this.getScrollContainer();
      if (container && container !== window && container instanceof Element) {
        return container.scrollTop;
      }
      return window.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0;
    }
    /**
     * Scroll down by exactly one viewport height with smooth behavior.
     */
    scrollOneStep() {
      return new Promise((resolve) => {
        const scrollDistance = window.innerHeight;
        window.scrollBy({
          top: scrollDistance,
          behavior: "smooth"
        });
        const container = this.getScrollContainer();
        if (container && container !== window && container instanceof Element) {
          container.scrollBy({
            top: scrollDistance,
            behavior: "smooth"
          });
        }
        document.documentElement.scrollBy({
          top: scrollDistance,
          behavior: "smooth"
        });
        document.body.scrollBy({
          top: scrollDistance,
          behavior: "smooth"
        });
        let lastY = this.getCurrentScrollY();
        let sameCount = 0;
        const checkScroll = setInterval(() => {
          if (this.state !== "running") {
            clearInterval(checkScroll);
            resolve();
            return;
          }
          const currentY = this.getCurrentScrollY();
          if (Math.abs(currentY - lastY) < 5) {
            sameCount++;
            if (sameCount >= 2) {
              clearInterval(checkScroll);
              resolve();
            }
          } else {
            sameCount = 0;
            lastY = currentY;
          }
        }, 100);
        setTimeout(() => {
          clearInterval(checkScroll);
          resolve();
        }, 1e3);
      });
    }
    /**
     * Wait for new posts, page height increase, or timeout.
     */
    waitForNewPosts() {
      return new Promise((resolve) => {
        const initialHeight = Math.max(
          document.body.scrollHeight,
          document.documentElement.scrollHeight
        );
        const initialPostCount = this.getLinkedInPostElements().length;
        const initialProcessedCount = this.processedPostIds.size;
        let resolved = false;
        const finishWait = (hasNewContent) => {
          if (resolved) return;
          resolved = true;
          this.cleanupWait();
          if (hasNewContent) {
            console.log("[AutoScroll] New posts detected");
          }
          resolve(hasNewContent);
        };
        try {
          const targetNode = document.querySelector(".scaffold-finite-scroll") || document.body;
          this.activeObserver = new MutationObserver(() => {
            if (this.hasNewContent(initialHeight, initialPostCount, initialProcessedCount)) {
              finishWait(true);
            }
          });
          this.activeObserver.observe(targetNode, {
            childList: true,
            subtree: true
          });
        } catch (e) {
          console.warn("[AutoScroll] MutationObserver setup warning:", e);
        }
        this.activePolling = setInterval(() => {
          if (this.state !== "running") {
            finishWait(false);
            return;
          }
          if (this.hasNewContent(initialHeight, initialPostCount, initialProcessedCount)) {
            finishWait(true);
          }
        }, 200);
        this.activeTimeout = setTimeout(() => {
          const finalHasNew = this.hasNewContent(initialHeight, initialPostCount, initialProcessedCount);
          finishWait(finalHasNew);
        }, this.options.scrollWaitTimeoutMs);
      });
    }
    /**
     * Check if page height increased or new posts appeared.
     */
    hasNewContent(initialHeight, initialPostCount, initialProcessedCount) {
      const container = this.getScrollContainer();
      const containerHeight = container instanceof Element ? container.scrollHeight : 0;
      const currentHeight = Math.max(
        document.body.scrollHeight,
        document.documentElement.scrollHeight,
        containerHeight
      );
      if (currentHeight > initialHeight + 20) {
        return true;
      }
      const currentPosts = this.getLinkedInPostElements();
      if (currentPosts.length > initialPostCount) {
        return true;
      }
      for (const post of currentPosts) {
        const id = this.getPostId(post);
        if (!this.processedPostIds.has(id)) {
          return true;
        }
      }
      return false;
    }
    /**
     * Check if max posts limit was reached.
     */
    isMaxPostsReached() {
      return this.totalPostsProcessed >= this.options.maxPosts;
    }
    /**
     * Check if max runtime limit was reached.
     */
    isMaxRuntimeReached() {
      if (this.options.maxRuntimeMs === Infinity) return false;
      return Date.now() - this.startTime >= this.options.maxRuntimeMs;
    }
    /**
     * Clean up observers and timers from wait cycle.
     */
    cleanupWait() {
      if (this.activeObserver) {
        this.activeObserver.disconnect();
        this.activeObserver = null;
      }
      if (this.activeTimeout) {
        clearTimeout(this.activeTimeout);
        this.activeTimeout = null;
      }
      if (this.activePolling) {
        clearInterval(this.activePolling);
        this.activePolling = null;
      }
    }
    /**
     * Full cleanup on stop.
     */
    cleanup() {
      this.cleanupWait();
      this.resumeResolver = null;
    }
  };
  var defaultAutoScrollController = new AutoScrollController();
  function startAutoScroll(options) {
    return defaultAutoScrollController.startAutoScroll(options);
  }
  function pauseAutoScroll() {
    defaultAutoScrollController.pauseAutoScroll();
  }
  function resumeAutoScroll() {
    defaultAutoScrollController.resumeAutoScroll();
  }
  function stopAutoScroll() {
    defaultAutoScrollController.stopAutoScroll();
  }
  function isRunning() {
    return defaultAutoScrollController.isRunning();
  }

  // src/content/content-script.ts
  async function scrapeVisiblePosts2() {
    autoScan();
  }
  window.scrapeVisiblePosts = scrapeVisiblePosts2;
  window.startAutoScroll = startAutoScroll;
  window.pauseAutoScroll = pauseAutoScroll;
  window.resumeAutoScroll = resumeAutoScroll;
  window.stopAutoScroll = stopAutoScroll;
  window.isRunning = isRunning;
  window.AutoScrollController = AutoScrollController;
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.action === "START_AUTO_SCROLL" || message.action === "START_SCRAPING") {
      startAutoScroll(message.options);
      sendResponse({ status: "started" });
      return true;
    }
    if (message.action === "STOP_AUTO_SCROLL" || message.action === "STOP_SCRAPING") {
      stopAutoScroll();
      sendResponse({ status: "stopped" });
      return true;
    }
    if (message.action === "PAUSE_AUTO_SCROLL" || message.action === "PAUSE_SCRAPING") {
      pauseAutoScroll();
      sendResponse({ status: "paused" });
      return true;
    }
    if (message.action === "RESUME_AUTO_SCROLL" || message.action === "RESUME_SCRAPING") {
      resumeAutoScroll();
      sendResponse({ status: "resumed" });
      return true;
    }
    if (message.action === "GET_AUTO_SCROLL_STATUS") {
      sendResponse({ running: isRunning() });
      return true;
    }
    if (message.action === "SCAN_PAGE") {
      try {
        if (document.body) {
          observer.observe(document.body, { childList: true, subtree: true });
        }
      } catch (e) {
      }
      handleScanPage().then(sendResponse).catch((err) => {
        sendResponse({ action: "SCAN_ERROR", error: err.message });
      });
      return true;
    }
    if (message.action === "SCAN_CONTACT_PAGES") {
      handleScanContactPages().then(sendResponse).catch((err) => {
        sendResponse({ action: "SCAN_ERROR", error: err.message });
      });
      return true;
    }
    if (message.action === "GET_PAGE_INFO") {
      const company = detectCompany();
      const relatedPages = detectRelatedPages();
      sendResponse({
        action: "PAGE_INFO",
        company,
        relatedPages,
        url: window.location.href
      });
      return true;
    }
    return false;
  });
  async function handleScanPage() {
    const emails = extractEmails();
    const company = detectCompany();
    const relatedPages = detectRelatedPages();
    return {
      action: "SCAN_COMPLETE",
      emails,
      company,
      relatedPages,
      url: window.location.href
    };
  }
  async function handleScanContactPages() {
    const currentEmails = extractEmails();
    const company = detectCompany();
    const relatedPages = detectRelatedPages();
    const allEmails = [...currentEmails];
    const scannedPages = [window.location.href];
    const urlsToScan = [
      ...relatedPages.contactUrls,
      ...relatedPages.aboutUrls,
      ...relatedPages.careersUrls
    ];
    const uniqueUrls = [...new Set(urlsToScan)].filter((url) => url !== window.location.href);
    const pagesToScan = uniqueUrls.slice(0, 6);
    for (const url of pagesToScan) {
      try {
        const response = await fetch(url, {
          method: "GET",
          headers: { "Accept": "text/html" },
          signal: AbortSignal.timeout(8e3)
        });
        if (!response.ok) continue;
        const html = await response.text();
        const pageEmails = extractEmailsFromHTML(html, `page:${new URL(url).pathname}`);
        allEmails.push(...pageEmails);
        scannedPages.push(url);
      } catch {
        console.log(`[Outreach AI] Failed to scan: ${url}`);
      }
    }
    const emailMap = /* @__PURE__ */ new Map();
    for (const entry of allEmails) {
      const key = entry.email.toLowerCase();
      if (!emailMap.has(key)) {
        emailMap.set(key, entry);
      } else {
        const existing = emailMap.get(key);
        if (existing.classification === "Unknown" && entry.classification !== "Unknown") {
          emailMap.set(key, entry);
        }
      }
    }
    return {
      action: "SCAN_COMPLETE",
      emails: Array.from(emailMap.values()),
      company,
      relatedPages,
      url: window.location.href,
      scannedPages
    };
  }
  function autoScan() {
    try {
      const emails = extractEmails();
      const company = detectCompany();
      const relatedPages = detectRelatedPages();
      if (emails.length > 0 || company && company.name) {
        chrome.runtime.sendMessage({
          action: "SAVE_AUTO_SCAN",
          payload: {
            url: window.location.href,
            emails,
            company,
            relatedPages
          }
        }).catch(() => {
        });
      }
    } catch (err) {
      console.error("[Outreach AI] Auto-scan error:", err);
    }
  }
  var mutationTimeout;
  var observer = new MutationObserver(() => {
    clearTimeout(mutationTimeout);
    mutationTimeout = setTimeout(() => {
      autoScan();
    }, 2e3);
  });
  async function initAutoScan() {
    if (window.self !== window.top || window.__OUTREACH_AI_INITIALIZED__) {
      return;
    }
    window.__OUTREACH_AI_INITIALIZED__ = true;
    try {
      const domain = window.location.hostname;
      if (domain === "mail.google.com" || domain === "gmail.com" || domain.includes("google.com") || domain.includes("outlook.live.com") || domain.includes("outlook.office.com") || domain.includes("mail.yahoo.com") || domain.includes("outreach.aditya07.me") || domain.includes("outreachai.aditya07.me") || domain === "localhost") {
        console.log(`[Outreach AI] Blocklisted domain ${domain} bypassed.`);
        return;
      }
      const result = await chrome.storage.local.get("allowed_domains");
      const allowed = result.allowed_domains || [];
      if (allowed.includes(domain)) {
        autoScan();
        if (document.body) {
          observer.observe(document.body, { childList: true, subtree: true });
        } else {
          window.addEventListener("load", () => {
            if (document.body) {
              observer.observe(document.body, { childList: true, subtree: true });
            }
          });
        }
      } else {
        console.log(`[Outreach AI] Auto-scanning is disabled for ${domain}. Enable in extension popup.`);
      }
    } catch (err) {
      console.error("[Outreach AI] Init error:", err);
    }
  }
  if (document.readyState === "complete" || document.readyState === "interactive") {
    initAutoScan();
  } else {
    window.addEventListener("DOMContentLoaded", initAutoScan);
  }
  console.log("[Outreach AI] Domain-whitelisted background auto-scan active");
})();
