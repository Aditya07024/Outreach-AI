// src/background/service-worker.ts
var DEFAULT_API_URL = "https://api.outreachai.aditya07.me";
var STORAGE_KEYS = {
  TOKEN: "outreach_jwt_token",
  API_URL: "outreach_api_url"
};
async function getToken() {
  const result = await chrome.storage.local.get(STORAGE_KEYS.TOKEN);
  return result[STORAGE_KEYS.TOKEN] || null;
}
async function apiRequest(path, options = {}) {
  const token = await getToken();
  if (!token) {
    throw new Error("Not authenticated. Please log in.");
  }
  const candidateUrls = [
    "https://api.outreachai.aditya07.me",
    "https://outreach.aditya07.me"
  ];
  const storageData = await chrome.storage.local.get(STORAGE_KEYS.API_URL);
  if (storageData[STORAGE_KEYS.API_URL]) {
    candidateUrls.unshift(storageData[STORAGE_KEYS.API_URL]);
  }
  let lastError = null;
  for (const baseUrl of candidateUrls) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3500);
    try {
      const url = `${baseUrl.replace(/\/+$/, "")}${path}`;
      const headers = {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
        ...options.headers || {}
      };
      const response = await fetch(url, {
        ...options,
        headers,
        signal: controller.signal
      });
      clearTimeout(timeout);
      if (response.status === 401 || response.status === 403) {
        await chrome.storage.local.remove([STORAGE_KEYS.TOKEN, "cached_user"]);
        throw new Error("Session expired. Please log in again.");
      }
      if (!response.ok) {
        const body = await response.json().catch(() => ({ error: `API error: ${response.status}` }));
        throw new Error(body.error || `API error: ${response.status}`);
      }
      return await response.json();
    } catch (err) {
      clearTimeout(timeout);
      lastError = err;
      if (err.message?.includes("Session expired") || err.message?.includes("Not authenticated")) {
        throw err;
      }
    }
  }
  throw lastError || new Error("Failed to connect to server.");
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message).then(sendResponse).catch((err) => {
    sendResponse({ error: err.message || "Unknown error" });
  });
  return true;
});
async function handleMessage(message) {
  switch (message.action) {
    // ─── Authentication ───
    case "LOGIN": {
      const { token } = message;
      if (!token) throw new Error("Token is required.");
      await chrome.storage.local.remove(STORAGE_KEYS.API_URL);
      await chrome.storage.local.set({
        [STORAGE_KEYS.TOKEN]: token
      });
      const status = await apiRequest("/api/extension/status");
      await chrome.storage.local.set({ cached_user: status.user });
      return { success: true, user: status.user };
    }
    case "LOGOUT": {
      await chrome.storage.local.remove([STORAGE_KEYS.TOKEN, STORAGE_KEYS.API_URL, "cached_user"]);
      return { success: true };
    }
    case "CHECK_AUTH": {
      const token = await getToken();
      if (!token) return { authenticated: false };
      try {
        const status = await apiRequest("/api/extension/status");
        await chrome.storage.local.set({ cached_user: status.user });
        return { authenticated: true, user: status.user };
      } catch (err) {
        if (err.message?.includes("Session expired") || err.message?.includes("Not authenticated") || err.message?.includes("401") || err.message?.includes("403")) {
          await chrome.storage.local.remove([STORAGE_KEYS.TOKEN, "cached_user"]);
          return { authenticated: false };
        }
        const storageData = await chrome.storage.local.get("cached_user");
        if (storageData.cached_user) {
          return {
            authenticated: true,
            user: storageData.cached_user,
            offline: true
          };
        }
        await chrome.storage.local.remove([STORAGE_KEYS.TOKEN, "cached_user"]);
        return { authenticated: false, error: err.message };
      }
    }
    case "GET_SETTINGS": {
      return { apiUrl: DEFAULT_API_URL };
    }
    // ─── Cache Management ───
    case "SAVE_AUTO_SCAN": {
      const { url, emails, company, relatedPages } = message.payload;
      const key = `autoscan_${url}`;
      await chrome.storage.local.set({
        [key]: {
          url,
          emails,
          company,
          relatedPages,
          timestamp: Date.now()
        }
      });
      const token = await getToken();
      const storageData = await chrome.storage.local.get("selected_campaign_id");
      const campaignId = storageData.selected_campaign_id;
      if (token && campaignId && emails && emails.length > 0) {
        try {
          const contactsPayload = emails.map((e) => ({
            email: e.email,
            classification: e.classification,
            company: company?.name,
            sourceUrl: url
          }));
          await apiRequest("/api/extension/sync", {
            method: "POST",
            body: JSON.stringify({
              campaignId,
              contacts: contactsPayload,
              companyName: company?.name,
              companyDomain: company?.domain,
              sourceUrl: url
            })
          });
          console.log(`[Outreach AI] Background auto-synced ${emails.length} contacts to campaign ${campaignId}`);
        } catch (err) {
          console.error("[Outreach AI] Background auto-sync failed:", err);
        }
      }
      return { success: true };
    }
    case "GET_CACHED_SCAN": {
      const { url } = message;
      const key = `autoscan_${url}`;
      const result = await chrome.storage.local.get(key);
      return result[key] || null;
    }
    // ─── Campaigns ───
    case "GET_CAMPAIGNS": {
      return await apiRequest("/api/extension/campaigns");
    }
    case "CREATE_CAMPAIGN": {
      const { name, description } = message;
      return await apiRequest("/api/extension/campaigns", {
        method: "POST",
        body: JSON.stringify({ name, description })
      });
    }
    // ─── Sync Contacts ───
    case "SYNC_CONTACTS": {
      let { campaignId, contacts, companyName, companyDomain, sourceUrl, excludeGmail } = message;
      if (excludeGmail === void 0) {
        const stored = await chrome.storage.local.get("exclude_gmail");
        excludeGmail = stored.exclude_gmail !== false;
      }
      return await apiRequest("/api/extension/sync", {
        method: "POST",
        body: JSON.stringify({ campaignId, contacts, companyName, companyDomain, sourceUrl, excludeGmail })
      });
    }
    // ─── Content Script Relay ───
    case "START_AUTO_SCROLL":
    case "STOP_AUTO_SCROLL":
    case "PAUSE_AUTO_SCROLL":
    case "RESUME_AUTO_SCROLL":
    case "GET_AUTO_SCROLL_STATUS":
    case "SCAN_ACTIVE_TAB":
    case "SCAN_CONTACT_PAGES":
    case "GET_PAGE_INFO": {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const tab = tabs[0];
      if (!tab?.id) throw new Error("No active tab found.");
      const payloadAction = message.action === "SCAN_ACTIVE_TAB" ? "SCAN_PAGE" : message.action;
      return await sendTabMessageWithFallback(tab.id, { ...message, action: payloadAction });
    }
    default:
      throw new Error(`Unknown action: ${message.action}`);
  }
}
async function sendTabMessageWithFallback(tabId, message) {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch (err) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["content.js"]
      });
      return await chrome.tabs.sendMessage(tabId, message);
    } catch (injectErr) {
      if (message.action === "GET_PAGE_INFO") {
        return { action: "PAGE_INFO", company: null, relatedPages: { contactUrls: [], aboutUrls: [], careersUrls: [] }, url: "" };
      }
      throw new Error(
        "Please refresh this tab or try scanning a different website. Note that standard security policies prevent extension execution on internal chrome:// pages."
      );
    }
  }
}
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === "install") {
    try {
      const token = await getToken();
      if (!token) {
        chrome.tabs.create({
          url: "https://outreach.aditya07.me/extension-login",
          active: true
        });
      }
    } catch (err) {
      chrome.tabs.create({
        url: "https://outreach.aditya07.me/extension-login",
        active: true
      });
    }
  }
});
console.log("[Outreach AI] Background service worker loaded");
